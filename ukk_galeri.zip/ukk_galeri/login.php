<!DOCTYPE html>
<html>

<head>
<title>LOGIN</title>
<link rel="stylesheet" href="style-2.css">
</head>

<body>
<header>
<a class="logoku" href="index.php">FOTO GALLERI</a>
<nav class="navigasi">
<a href="daftar.php" class="daftar">DAFTAR</a>
<a href="login.php" class="masuk">MASUK</a>
</nav>
</header>

<div class="cover">
<div class="form login">
<h2>LOGIN</h2>
<form action="config/aksi_login.php" method="POST">
<div class="input-box">
<input type="text" name="username" required>
<label>Username</label>
</div>
<div class="input-box">
<input type="password" name="password" required>
<label>Password</label>
</div>
<button type="submit" class="btn">Login</button>
<div class="login-register">
<p>belum punya akun? <a href="daftar.php" class="register-link">DAFTAR</a>
</p>
</div>
</form>


<script src="script.js"></script>